
"use client";

import { useState } from "react";
import { optimizeUserPrompt } from "@/ai/flows/optimize-user-prompt";
import { recommendAiToolsAndPrompts } from "@/ai/flows/recommend-ai-tools-and-prompts";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Zap, Sparkles, Copy, Check, Info, Rocket } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function PromptsPage() {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("optimize");
  
  // Prompt Optimizer State
  const [promptIdea, setPromptIdea] = useState("");
  const [targetPlatform, setTargetPlatform] = useState("General");
  const [isOptimizing, setIsOptimizing] = useState(false);
  const [optimizedResult, setOptimizedResult] = useState<any>(null);

  // Matchmaker State
  const [projectDescription, setProjectDescription] = useState("");
  const [isMatching, setIsMatching] = useState(false);
  const [matchResult, setMatchResult] = useState<any>(null);

  const [copied, setCopied] = useState(false);

  const handleOptimize = async () => {
    if (!promptIdea) return;
    setIsOptimizing(true);
    try {
      const result = await optimizeUserPrompt({ idea: promptIdea, targetPlatform: targetPlatform as any });
      setOptimizedResult(result);
    } catch (error) {
      toast({ title: "Error", description: "Failed to optimize prompt. Please try again.", variant: "destructive" });
    } finally {
      setIsOptimizing(false);
    }
  };

  const handleMatch = async () => {
    if (!projectDescription) return;
    setIsMatching(true);
    try {
      const result = await recommendAiToolsAndPrompts({ projectDescription });
      setMatchResult(result);
    } catch (error) {
      toast({ title: "Error", description: "Failed to find recommendations. Please try again.", variant: "destructive" });
    } finally {
      setIsMatching(false);
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
    toast({ title: "Copied!", description: "Text copied to clipboard." });
  };

  return (
    <div className="max-w-5xl mx-auto px-4 py-20 space-y-12">
      <div className="text-center space-y-4">
        <h1 className="text-4xl md:text-6xl font-headline font-bold">AI <span className="text-gradient">Intelligence Lab</span></h1>
        <p className="text-muted-foreground text-lg">Use our custom-trained models to optimize your workflow and creative output.</p>
      </div>

      <Tabs defaultValue="optimize" onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-2 h-16 glass rounded-2xl p-1 mb-8">
          <TabsTrigger value="optimize" className="rounded-xl data-[state=active]:bg-primary data-[state=active]:text-primary-foreground text-lg gap-2">
            <Zap className="w-5 h-5" /> Prompt Optimizer
          </TabsTrigger>
          <TabsTrigger value="matchmaker" className="rounded-xl data-[state=active]:bg-secondary data-[state=active]:text-secondary-foreground text-lg gap-2">
            <Sparkles className="w-5 h-5" /> AI Matchmaker
          </TabsTrigger>
        </TabsList>

        <TabsContent value="optimize" className="space-y-8">
          <Card className="glass border-white/5 rounded-3xl overflow-hidden">
            <CardHeader>
              <CardTitle className="text-2xl font-headline">Generative Prompt Optimizer</CardTitle>
              <CardDescription>Transform simple ideas into highly detailed prompts for Midjourney, ChatGPT, or DALL-E.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <label className="text-sm font-medium text-muted-foreground uppercase tracking-wider">Target Platform</label>
                <Select value={targetPlatform} onValueChange={setTargetPlatform}>
                  <SelectTrigger className="glass border-white/10 h-12">
                    <SelectValue placeholder="Select platform" />
                  </SelectTrigger>
                  <SelectContent className="glass border-white/10">
                    <SelectItem value="General">General Purpose</SelectItem>
                    <SelectItem value="Midjourney">Midjourney / Art</SelectItem>
                    <SelectItem value="ChatGPT">ChatGPT / Writing</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-4">
                <label className="text-sm font-medium text-muted-foreground uppercase tracking-wider">Your Prompt Idea</label>
                <Textarea 
                  placeholder="e.g., A cybernetic owl flying through a futuristic city neon lights"
                  className="glass border-white/10 min-h-[150px] text-lg resize-none p-6"
                  value={promptIdea}
                  onChange={(e) => setPromptIdea(e.target.value)}
                />
              </div>
              <Button 
                onClick={handleOptimize} 
                disabled={isOptimizing || !promptIdea}
                className="w-full h-14 bg-primary text-primary-foreground hover:bg-primary/90 rounded-2xl text-lg font-bold neon-glow-primary gap-3"
              >
                {isOptimizing ? "Optimizing..." : <><Zap className="w-5 h-5" /> Enhance Prompt</>}
              </Button>
            </CardContent>
          </Card>

          {optimizedResult && (
            <div className="animate-in fade-in slide-in-from-bottom duration-500 space-y-6">
              <div className="glass border-primary/20 rounded-3xl p-8 space-y-6">
                <div className="flex items-center justify-between">
                  <h3 className="text-xl font-headline font-bold text-primary flex items-center gap-2">
                    <Check className="w-6 h-6" /> Result
                  </h3>
                  <Button variant="outline" size="sm" onClick={() => copyToClipboard(optimizedResult.optimizedPrompt)} className="glass border-white/10 gap-2">
                    {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />} Copy
                  </Button>
                </div>
                <div className="bg-white/5 p-6 rounded-2xl border border-white/5 font-body leading-relaxed text-lg">
                  {optimizedResult.optimizedPrompt}
                </div>
                {optimizedResult.explanation && (
                  <div className="flex gap-4 p-4 rounded-2xl bg-primary/5 border border-primary/10">
                    <Info className="w-6 h-6 text-primary shrink-0" />
                    <p className="text-sm text-muted-foreground leading-relaxed italic">
                      <span className="text-primary font-bold not-italic">Strategy:</span> {optimizedResult.explanation}
                    </p>
                  </div>
                )}
              </div>
            </div>
          )}
        </TabsContent>

        <TabsContent value="matchmaker" className="space-y-8">
          <Card className="glass border-white/5 rounded-3xl overflow-hidden">
            <CardHeader>
              <CardTitle className="text-2xl font-headline">Personalized AI Matchmaker</CardTitle>
              <CardDescription>Tell us about your project or workflow, and we'll suggest the best AI stack.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <label className="text-sm font-medium text-muted-foreground uppercase tracking-wider">Describe your project or workflow</label>
                <Textarea 
                  placeholder="e.g., I'm a small business owner looking to automate my social media content creation and customer support responses."
                  className="glass border-white/10 min-h-[150px] text-lg resize-none p-6"
                  value={projectDescription}
                  onChange={(e) => setProjectDescription(e.target.value)}
                />
              </div>
              <Button 
                onClick={handleMatch} 
                disabled={isMatching || !projectDescription}
                className="w-full h-14 bg-secondary text-secondary-foreground hover:bg-secondary/90 rounded-2xl text-lg font-bold neon-glow-secondary gap-3"
              >
                {isMatching ? "Analyzing..." : <><Rocket className="w-5 h-5" /> Find My AI Stack</>}
              </Button>
            </CardContent>
          </Card>

          {matchResult && (
            <div className="animate-in fade-in slide-in-from-bottom duration-500 grid grid-cols-1 lg:grid-cols-2 gap-8">
              <div className="glass border-secondary/20 rounded-3xl p-8 space-y-6">
                <h3 className="text-xl font-headline font-bold text-secondary flex items-center gap-2">
                  <Rocket className="w-6 h-6" /> Recommended Tools
                </h3>
                <div className="space-y-4">
                  {matchResult.recommendedTools.map((tool: any, idx: number) => (
                    <div key={idx} className="bg-white/5 p-4 rounded-2xl border border-white/5">
                      <h4 className="font-bold text-white mb-1">{tool.name}</h4>
                      <p className="text-sm text-muted-foreground">{tool.description}</p>
                    </div>
                  ))}
                </div>
              </div>

              <div className="glass border-secondary/20 rounded-3xl p-8 space-y-6">
                <h3 className="text-xl font-headline font-bold text-secondary flex items-center gap-2">
                  <Zap className="w-6 h-6" /> Strategy & Prompts
                </h3>
                <div className="space-y-4">
                  {matchResult.recommendedPrompts.map((prompt: any, idx: number) => (
                    <div key={idx} className="bg-white/5 p-4 rounded-2xl border border-white/5 space-y-2">
                      <div className="flex items-center justify-between">
                        <h4 className="font-bold text-white text-sm">{prompt.useCase}</h4>
                        <Button variant="ghost" size="icon" onClick={() => copyToClipboard(prompt.promptExample)} className="h-8 w-8">
                          <Copy className="w-4 h-4" />
                        </Button>
                      </div>
                      <p className="text-xs text-muted-foreground bg-black/20 p-2 rounded-lg font-mono">
                        {prompt.promptExample}
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
