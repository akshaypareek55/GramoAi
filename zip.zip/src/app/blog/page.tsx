
"use client";

import { Badge } from "@/components/ui/badge";
import { ArrowRight, Clock, User } from "lucide-react";
import Image from "next/image";
import Link from "next/link";

const posts = [
  {
    title: "OpenAI Announces Strawberry: A Reasoning Breakthrough",
    excerpt: "The latest model from OpenAI promises advanced logic and mathematical problem-solving capabilities.",
    category: "AI News",
    author: "Elena Vance",
    date: "Sep 12, 2024",
    readTime: "5 min read",
    image: "https://picsum.photos/seed/blog1/800/600"
  },
  {
    title: "10 AI Tools That Will Replace Your Marketing Agency",
    excerpt: "From copywriting to ad management, these tools are changing the landscape of digital marketing.",
    category: "Resources",
    author: "Marcus Thorne",
    date: "Sep 10, 2024",
    readTime: "8 min read",
    image: "https://picsum.photos/seed/blog2/800/600"
  },
  {
    title: "The Ethics of Generative AI in the Art World",
    excerpt: "A deep dive into the legal and ethical challenges facing digital artists in the age of Stable Diffusion.",
    category: "Editorial",
    author: "Sarah Jenkins",
    date: "Sep 08, 2024",
    readTime: "12 min read",
    image: "https://picsum.photos/seed/blog3/800/600"
  }
];

export default function BlogPage() {
  return (
    <div className="max-w-7xl mx-auto px-4 py-20 space-y-16">
      <div className="space-y-4 max-w-3xl">
        <h1 className="text-4xl md:text-6xl font-headline font-bold">The <span className="text-gradient">GramoAI Blog</span></h1>
        <p className="text-muted-foreground text-lg">Insights, tutorials, and news from the frontlines of the AI revolution.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
        {/* Featured Post */}
        <div className="lg:col-span-2 group cursor-pointer">
          <div className="glass rounded-[3rem] overflow-hidden border-white/5 flex flex-col lg:flex-row h-full">
            <div className="relative lg:w-3/5 h-[300px] lg:h-auto overflow-hidden">
              <Image 
                src="https://picsum.photos/seed/featured/1200/800" 
                alt="Featured Post" 
                fill 
                className="object-cover group-hover:scale-105 transition-transform duration-700"
              />
            </div>
            <div className="p-10 lg:w-2/5 flex flex-col justify-center space-y-6">
              <Badge className="w-fit bg-primary text-primary-foreground">Featured Story</Badge>
              <h2 className="text-3xl md:text-4xl font-headline font-bold group-hover:text-primary transition-colors">Why 2024 is the Year of Multi-Modal AI</h2>
              <p className="text-muted-foreground leading-relaxed">As text, image, and video models converge, the way we interact with technology is fundamentally shifting. Here's what you need to know.</p>
              <div className="flex items-center gap-4 text-sm text-muted-foreground">
                <div className="flex items-center gap-2"><User className="w-4 h-4" /> Julian K.</div>
                <div className="flex items-center gap-2"><Clock className="w-4 h-4" /> 15 min read</div>
              </div>
              <button className="flex items-center gap-2 text-primary font-bold group">Read Article <ArrowRight className="w-4 h-4 group-hover:translate-x-2 transition-transform" /></button>
            </div>
          </div>
        </div>

        {/* Regular Posts */}
        {posts.map((post, idx) => (
          <div key={idx} className="glass rounded-3xl overflow-hidden border-white/5 group hover:border-primary/20 transition-all duration-300">
            <div className="relative h-64 overflow-hidden">
              <Image src={post.image} alt={post.title} fill className="object-cover group-hover:scale-110 transition-transform duration-500" />
              <div className="absolute top-4 left-4">
                <Badge variant="secondary" className="bg-background/80 backdrop-blur-sm border-white/10">{post.category}</Badge>
              </div>
            </div>
            <div className="p-8 space-y-4">
              <h3 className="text-2xl font-headline font-bold leading-tight group-hover:text-primary transition-colors">{post.title}</h3>
              <p className="text-muted-foreground text-sm line-clamp-2">{post.excerpt}</p>
              <div className="pt-4 flex items-center justify-between text-xs text-muted-foreground border-t border-white/5 pt-6">
                <div className="flex items-center gap-2"><User className="w-4 h-4" /> {post.author}</div>
                <div className="flex items-center gap-2"><Clock className="w-4 h-4" /> {post.readTime}</div>
              </div>
            </div>
          </div>
        ))}
      </div>
      
      <div className="flex justify-center pt-12">
        <Button variant="outline" size="lg" className="glass border-white/10 px-12 h-14 rounded-full">Load More Articles</Button>
      </div>
    </div>
  );
}
