
"use client";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Mail, MessageSquare, MapPin, Send } from "lucide-react";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";

export default function ContactPage() {
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      toast({ title: "Message Sent!", description: "We'll get back to you shortly." });
    }, 1500);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-20 space-y-16">
      <div className="text-center space-y-4 max-w-2xl mx-auto">
        <h1 className="text-4xl md:text-6xl font-headline font-bold">Get in <span className="text-gradient">Touch</span></h1>
        <p className="text-muted-foreground text-lg">Have questions about AI or want to list your tool? Drop us a message below.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-start">
        <div className="space-y-12">
          <div className="grid gap-8">
            <div className="flex gap-6 items-start">
              <div className="p-4 bg-primary/10 rounded-2xl">
                <Mail className="w-6 h-6 text-primary" />
              </div>
              <div className="space-y-1">
                <h3 className="font-headline font-bold text-xl">Email Us</h3>
                <p className="text-muted-foreground">General Enquiries: hello@gramoai.com</p>
                <p className="text-muted-foreground">Support: support@gramoai.com</p>
              </div>
            </div>

            <div className="flex gap-6 items-start">
              <div className="p-4 bg-secondary/10 rounded-2xl">
                <MessageSquare className="w-6 h-6 text-secondary" />
              </div>
              <div className="space-y-1">
                <h3 className="font-headline font-bold text-xl">Community</h3>
                <p className="text-muted-foreground">Join our Discord for real-time AI discussions.</p>
                <button className="text-secondary hover:underline font-bold mt-2">Join Discord Channel</button>
              </div>
            </div>

            <div className="flex gap-6 items-start">
              <div className="p-4 bg-white/10 rounded-2xl">
                <MapPin className="w-6 h-6 text-white" />
              </div>
              <div className="space-y-1">
                <h3 className="font-headline font-bold text-xl">Office</h3>
                <p className="text-muted-foreground">123 Futura Way, Tech District, Silicon Valley, CA</p>
              </div>
            </div>
          </div>
          
          <div className="glass p-8 rounded-3xl border-white/5 space-y-4">
            <h4 className="font-bold">Are you an AI Developer?</h4>
            <p className="text-sm text-muted-foreground">We are always looking for cutting-edge tools to feature in our directory. If you've built something amazing, let us know!</p>
            <Button variant="outline" className="glass border-white/10">Submit a Tool</Button>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="glass p-10 rounded-[2.5rem] border-white/5 space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <label className="text-sm font-medium text-muted-foreground">First Name</label>
              <Input placeholder="John" className="glass border-white/10 h-12" required />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium text-muted-foreground">Last Name</label>
              <Input placeholder="Doe" className="glass border-white/10 h-12" required />
            </div>
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium text-muted-foreground">Email Address</label>
            <Input type="email" placeholder="john@example.com" className="glass border-white/10 h-12" required />
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium text-muted-foreground">Subject</label>
            <Input placeholder="How can we help?" className="glass border-white/10 h-12" required />
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium text-muted-foreground">Message</label>
            <Textarea placeholder="Your message here..." className="glass border-white/10 min-h-[150px] resize-none" required />
          </div>
          <Button type="submit" disabled={loading} className="w-full h-14 bg-primary text-primary-foreground hover:bg-primary/90 neon-glow-primary rounded-2xl text-lg font-bold gap-2">
            {loading ? "Sending..." : <><Send className="w-5 h-5" /> Send Message</>}
          </Button>
        </form>
      </div>
    </div>
  );
}
