
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { LayoutDashboard, Heart, Zap, BookOpen, Settings, User, Trophy, TrendingUp } from "lucide-react";

export default function DashboardPage() {
  return (
    <div className="max-w-7xl mx-auto px-4 py-20 space-y-12">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
        <div className="space-y-1">
          <h1 className="text-3xl md:text-4xl font-headline font-bold">Welcome back, <span className="text-gradient">Creator</span></h1>
          <p className="text-muted-foreground">Here's your personal AI command center.</p>
        </div>
        <Button className="bg-primary text-primary-foreground hover:bg-primary/90 neon-glow-primary h-12 rounded-xl">
          Upgrade to Pro
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        {[
          { label: "Favorite Tools", value: "12", icon: Heart, color: "text-red-500" },
          { label: "Saved Prompts", value: "48", icon: Zap, color: "text-primary" },
          { label: "Guides Read", value: "3", icon: BookOpen, color: "text-secondary" },
          { label: "Arena Rank", value: "#142", icon: Trophy, color: "text-yellow-500" },
        ].map((stat, i) => (
          <Card key={i} className="glass border-white/5 rounded-3xl">
            <CardContent className="p-6 flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground mb-1">{stat.label}</p>
                <p className="text-2xl font-headline font-bold">{stat.value}</p>
              </div>
              <stat.icon className={`w-8 h-8 ${stat.color} opacity-80`} />
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <Card className="lg:col-span-2 glass border-white/5 rounded-[2rem]">
          <CardHeader>
            <CardTitle className="font-headline font-bold flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-primary" /> Learning Progress
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            {[
              { title: "AI Freelancing Mastery", progress: 65, status: "In Progress" },
              { title: "ChatGPT Advanced Prompts", progress: 100, status: "Completed" },
              { title: "No-Code SAAS Building", progress: 12, status: "Just Started" },
            ].map((course, i) => (
              <div key={i} className="space-y-2">
                <div className="flex justify-between items-center text-sm">
                  <span className="font-medium">{course.title}</span>
                  <span className="text-muted-foreground">{course.progress}%</span>
                </div>
                <div className="h-2 w-full bg-white/5 rounded-full overflow-hidden">
                  <div className="h-full bg-primary" style={{ width: `${course.progress}%` }} />
                </div>
              </div>
            ))}
          </CardContent>
        </Card>

        <Card className="glass border-white/5 rounded-[2rem]">
          <CardHeader>
            <CardTitle className="font-headline font-bold">Quick Actions</CardTitle>
          </CardHeader>
          <CardContent className="flex flex-col gap-4">
            <Button variant="outline" className="glass border-white/10 w-full justify-start h-12 gap-3">
              <Zap className="w-4 h-4 text-primary" /> New Prompt Test
            </Button>
            <Button variant="outline" className="glass border-white/10 w-full justify-start h-12 gap-3">
              <BookOpen className="w-4 h-4 text-secondary" /> Resume Last Guide
            </Button>
            <Button variant="outline" className="glass border-white/10 w-full justify-start h-12 gap-3">
              <Trophy className="w-4 h-4 text-white" /> Join Live Battle
            </Button>
            <Button variant="outline" className="glass border-white/10 w-full justify-start h-12 gap-3">
              <Settings className="w-4 h-4 text-muted-foreground" /> Account Settings
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
