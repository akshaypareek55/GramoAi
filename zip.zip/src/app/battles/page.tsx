
"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Zap, ThumbsUp, MessageSquare, Share2, Crown } from "lucide-react";
import Image from "next/image";
import { PlaceHolderImages } from "@/lib/placeholder-images";

const battles = [
  {
    id: 1,
    prompt: "A neon-lit cyberpunk street after rain, high detail, 8k, cinematic lighting.",
    toolA: { name: "Midjourney v6", image: "https://picsum.photos/seed/mj1/800/800", votes: 1240 },
    toolB: { name: "DALL-E 3", image: "https://picsum.photos/seed/de1/800/800", votes: 850 },
    status: "Live"
  },
  {
    id: 2,
    prompt: "Explain quantum entanglement to a five-year-old.",
    toolA: { name: "GPT-4o", text: "Imagine you have two magical pairs of socks...", votes: 3200 },
    toolB: { name: "Claude 3.5 Sonnet", text: "Think of two magic toys that always know...", votes: 3450 },
    status: "Completed",
    winner: "Claude 3.5 Sonnet"
  }
];

export default function BattlesPage() {
  const [activeVotes, setActiveVotes] = useState<Record<number, string>>({});

  const handleVote = (battleId: number, tool: string) => {
    setActiveVotes(prev => ({ ...prev, [battleId]: tool }));
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-20 space-y-12">
      <div className="space-y-4">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full glass border-primary/20 text-primary text-xs font-bold uppercase tracking-widest">
          <Zap className="w-3 h-3 fill-primary" /> Battle Arena
        </div>
        <h1 className="text-4xl md:text-6xl font-headline font-bold">Model <span className="text-gradient">Showdown</span></h1>
        <p className="text-muted-foreground text-lg max-w-2xl">Compare the latest AI models in real-time. The community decides who reigns supreme.</p>
      </div>

      <div className="space-y-16">
        {battles.map((battle) => (
          <div key={battle.id} className="space-y-8 animate-in fade-in slide-in-from-bottom duration-700">
            <div className="glass p-6 rounded-2xl border-white/5 bg-white/5">
              <h3 className="text-sm font-medium text-muted-foreground uppercase tracking-widest mb-2">Prompt</h3>
              <p className="text-lg italic">&ldquo;{battle.prompt}&rdquo;</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 relative">
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-10 hidden md:block">
                <div className="w-16 h-16 rounded-full bg-background border-4 border-white/10 flex items-center justify-center font-headline font-bold text-2xl text-gradient">VS</div>
              </div>

              {/* Side A */}
              <div className={`glass rounded-[2rem] overflow-hidden border-2 transition-all duration-300 ${activeVotes[battle.id] === 'A' ? 'border-primary' : 'border-white/5'}`}>
                <div className="relative aspect-square bg-black/40">
                  {battle.toolA.image ? (
                    <Image src={battle.toolA.image} alt={battle.toolA.name} fill className="object-cover" />
                  ) : (
                    <div className="p-8 h-full flex items-center justify-center text-center text-lg leading-relaxed">{battle.toolA.text}</div>
                  )}
                  {battle.winner === battle.toolA.name && (
                    <div className="absolute top-4 left-4 bg-yellow-500 text-black px-4 py-1 rounded-full font-bold flex items-center gap-2">
                      <Crown className="w-4 h-4" /> Winner
                    </div>
                  )}
                </div>
                <div className="p-6 flex items-center justify-between">
                  <div>
                    <h4 className="font-headline font-bold text-xl">{battle.toolA.name}</h4>
                    <p className="text-sm text-muted-foreground">{battle.toolA.votes.toLocaleString()} votes</p>
                  </div>
                  <Button 
                    onClick={() => handleVote(battle.id, 'A')}
                    disabled={!!activeVotes[battle.id]}
                    className={activeVotes[battle.id] === 'A' ? "bg-primary text-primary-foreground" : "glass border-white/10"}
                  >
                    <ThumbsUp className="w-4 h-4 mr-2" /> Vote
                  </Button>
                </div>
              </div>

              {/* Side B */}
              <div className={`glass rounded-[2rem] overflow-hidden border-2 transition-all duration-300 ${activeVotes[battle.id] === 'B' ? 'border-secondary' : 'border-white/5'}`}>
                <div className="relative aspect-square bg-black/40">
                  {battle.toolB.image ? (
                    <Image src={battle.toolB.image} alt={battle.toolB.name} fill className="object-cover" />
                  ) : (
                    <div className="p-8 h-full flex items-center justify-center text-center text-lg leading-relaxed">{battle.toolB.text}</div>
                  )}
                   {battle.winner === battle.toolB.name && (
                    <div className="absolute top-4 left-4 bg-yellow-500 text-black px-4 py-1 rounded-full font-bold flex items-center gap-2">
                      <Crown className="w-4 h-4" /> Winner
                    </div>
                  )}
                </div>
                <div className="p-6 flex items-center justify-between">
                  <div>
                    <h4 className="font-headline font-bold text-xl">{battle.toolB.name}</h4>
                    <p className="text-sm text-muted-foreground">{battle.toolB.votes.toLocaleString()} votes</p>
                  </div>
                  <Button 
                    onClick={() => handleVote(battle.id, 'B')}
                    disabled={!!activeVotes[battle.id]}
                    className={activeVotes[battle.id] === 'B' ? "bg-secondary text-secondary-foreground" : "glass border-white/10"}
                  >
                    <ThumbsUp className="w-4 h-4 mr-2" /> Vote
                  </Button>
                </div>
              </div>
            </div>
            
            <div className="flex items-center justify-center gap-6 text-muted-foreground">
              <button className="flex items-center gap-2 hover:text-white transition-colors"><MessageSquare className="w-4 h-4" /> 42 Comments</button>
              <button className="flex items-center gap-2 hover:text-white transition-colors"><Share2 className="w-4 h-4" /> Share Battle</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
