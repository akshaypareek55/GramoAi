
"use client";

import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { TrendingUp, DollarSign, Users, Clock, ArrowRight, Star } from "lucide-react";
import Image from "next/image";
import { PlaceHolderImages } from "@/lib/placeholder-images";
import Link from "next/link";

const guides = [
  {
    title: "AI Freelancing Mastery",
    desc: "How to use ChatGPT and Midjourney to dominate platforms like Upwork and Fiverr.",
    difficulty: "Intermediate",
    time: "4 Weeks",
    potential: "$2k - $10k / mo",
    image: "earning-guide-1",
    tag: "Freelancing"
  },
  {
    title: "The Faceless YouTube Empire",
    desc: "Build a viral YouTube channel using AI voices, scripts, and video generators.",
    difficulty: "Beginner",
    time: "2 Weeks",
    potential: "$1k - $5k / mo",
    image: "ai-tool-3",
    tag: "Content Creation"
  },
  {
    title: "SAAS with No-Code AI",
    desc: "Launch your own AI application without writing a single line of code.",
    difficulty: "Advanced",
    time: "8 Weeks",
    potential: "$5k+ / mo",
    image: "ai-tool-2",
    tag: "Entrepreneurship"
  }
];

export default function EarnPage() {
  return (
    <div className="max-w-7xl mx-auto px-4 py-20 space-y-12">
      <div className="space-y-4 max-w-3xl">
        <h1 className="text-4xl md:text-6xl font-headline font-bold">Expert <span className="text-gradient">Earning Guides</span></h1>
        <p className="text-muted-foreground text-lg">Professional monetization strategies focused on leveraging generative AI technology for revenue.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {guides.map((guide, idx) => (
          <div key={idx} className="glass rounded-[2rem] overflow-hidden flex flex-col hover:border-primary/20 transition-all duration-300">
            <div className="relative h-64">
              <Image 
                src={PlaceHolderImages.find(img => img.id === guide.image)?.imageUrl || "https://picsum.photos/seed/earn/600/400"}
                alt={guide.title}
                fill
                className="object-cover"
              />
              <div className="absolute top-4 left-4">
                <Badge className="bg-secondary text-secondary-foreground">{guide.tag}</Badge>
              </div>
            </div>
            
            <div className="p-8 flex-grow space-y-6">
              <h3 className="text-2xl font-headline font-bold">{guide.title}</h3>
              <p className="text-muted-foreground leading-relaxed">{guide.desc}</p>
              
              <div className="grid grid-cols-2 gap-4 border-t border-white/5 pt-6">
                <div className="flex items-center gap-2 text-sm">
                  <Clock className="w-4 h-4 text-primary" />
                  <span className="text-muted-foreground">{guide.time}</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <Star className="w-4 h-4 text-primary" />
                  <span className="text-muted-foreground">{guide.difficulty}</span>
                </div>
                <div className="flex items-center gap-2 text-sm col-span-2">
                  <DollarSign className="w-4 h-4 text-secondary" />
                  <span className="text-secondary font-bold">Est. Earnings: {guide.potential}</span>
                </div>
              </div>
              
              <Button className="w-full bg-white/5 border border-white/10 hover:bg-primary hover:text-primary-foreground group transition-all h-12 rounded-xl">
                Access Guide <ArrowRight className="ml-2 w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </Button>
            </div>
          </div>
        ))}
      </div>

      <div className="glass p-12 rounded-[3rem] border-white/5 bg-gradient-to-r from-primary/5 to-transparent flex flex-col md:flex-row items-center justify-between gap-8">
        <div className="space-y-4">
          <h2 className="text-3xl font-headline font-bold">Personalized Earning Strategy?</h2>
          <p className="text-muted-foreground">Get a custom roadmap based on your current skills and available time.</p>
        </div>
        <Link href="/prompts">
          <Button size="lg" className="bg-primary text-primary-foreground h-16 px-12 rounded-2xl text-lg font-bold neon-glow-primary">
            Get My Roadmap
          </Button>
        </Link>
      </div>
    </div>
  );
}
