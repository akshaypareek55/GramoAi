
"use client";

import { useState } from "react";
import { Search, Filter, ExternalLink, Star } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { PlaceHolderImages } from "@/lib/placeholder-images";
import Image from "next/image";

const categories = ["All", "Generative Art", "Writing", "Video", "Code", "Marketing", "Research"];

const tools = [
  { id: 1, name: "Midjourney", category: "Generative Art", desc: "The world's leading AI image generation platform.", rating: 4.9, trending: true, image: "ai-tool-2" },
  { id: 2, name: "ChatGPT", category: "Writing", desc: "Advanced conversational AI for information and creative work.", rating: 4.8, trending: true, image: "ai-tool-1" },
  { id: 3, name: "Runway Gen-2", category: "Video", desc: "Next-generation video creation and editing via text.", rating: 4.7, trending: false, image: "ai-tool-3" },
  { id: 4, name: "Jasper", category: "Writing", desc: "AI content platform designed specifically for marketing teams.", rating: 4.6, trending: false, image: "ai-tool-1" },
  { id: 5, name: "GitHub Copilot", category: "Code", desc: "Your AI pair programmer, suggesting code in real-time.", rating: 4.9, trending: true, image: "ai-tool-2" },
  { id: 6, name: "Perplexity", category: "Research", desc: "AI search engine that provides direct answers with citations.", rating: 4.8, trending: true, image: "ai-tool-3" },
];

export default function ToolsPage() {
  const [activeCategory, setActiveCategory] = useState("All");
  const [searchQuery, setSearchQuery] = useState("");

  const filteredTools = tools.filter(tool => 
    (activeCategory === "All" || tool.category === activeCategory) &&
    (tool.name.toLowerCase().includes(searchQuery.toLowerCase()) || tool.desc.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  return (
    <div className="max-w-7xl mx-auto px-4 py-20 space-y-12">
      <div className="space-y-4">
        <h1 className="text-4xl md:text-6xl font-headline font-bold">AI Tools <span className="text-gradient">Directory</span></h1>
        <p className="text-muted-foreground text-lg max-w-2xl">Discover and filter the best AI software across every industry.</p>
      </div>

      <div className="flex flex-col md:flex-row gap-6 items-center justify-between">
        <div className="relative w-full md:w-96">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input 
            placeholder="Search tools..." 
            className="pl-10 glass border-white/10"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        <div className="flex flex-wrap gap-2">
          {categories.map((cat) => (
            <Button 
              key={cat} 
              variant={activeCategory === cat ? "default" : "outline"}
              className={activeCategory === cat ? "bg-primary text-primary-foreground" : "glass border-white/10"}
              onClick={() => setActiveCategory(cat)}
            >
              {cat}
            </Button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {filteredTools.map((tool) => (
          <div key={tool.id} className="glass rounded-3xl border-white/5 overflow-hidden group hover:border-primary/20 transition-all duration-300">
            <div className="relative h-48 overflow-hidden">
              <Image 
                src={PlaceHolderImages.find(img => img.id === tool.image)?.imageUrl || "https://picsum.photos/seed/tool/400/300"}
                alt={tool.name}
                fill
                className="object-cover group-hover:scale-110 transition-transform duration-500"
              />
              <div className="absolute top-4 right-4 flex gap-2">
                {tool.trending && <Badge className="bg-primary text-primary-foreground">Trending</Badge>}
                <Badge variant="outline" className="bg-background/80 backdrop-blur-sm border-white/10">{tool.category}</Badge>
              </div>
            </div>
            <div className="p-6 space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-xl font-headline font-bold">{tool.name}</h3>
                <div className="flex items-center gap-1 text-primary text-sm">
                  <Star className="w-4 h-4 fill-primary" />
                  <span>{tool.rating}</span>
                </div>
              </div>
              <p className="text-muted-foreground text-sm leading-relaxed min-h-[48px]">
                {tool.desc}
              </p>
              <div className="pt-4 flex items-center justify-between">
                <Button variant="ghost" size="sm" className="hover:bg-primary/20 hover:text-primary gap-2">
                  Learn More
                </Button>
                <Button size="sm" className="bg-white/5 hover:bg-white/10 border border-white/10 gap-2">
                  Visit Site <ExternalLink className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
